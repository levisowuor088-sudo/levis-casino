import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { toggleMute, isMuted } from '../utils/audio';

const SoundControls: React.FC = () => {
  const [muted, setMuted] = useState(isMuted());

  const handleToggle = () => {
    const newState = toggleMute();
    setMuted(newState);
  };

  return (
    <div className="fixed bottom-4 right-4 z-40">
      <button
        onClick={handleToggle}
        className="p-3 bg-slate-800 rounded-full hover:bg-slate-700 border border-white/10 transition-colors shadow-lg"
      >
        {muted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
      </button>
    </div>
  );
};

export default SoundControls;