import React from 'react';
import { Coins, PlusCircle } from 'lucide-react';

interface HeaderProps {
  balance: number;
  onDeposit: () => void;
}

const Header: React.FC<HeaderProps> = ({ balance, onDeposit }) => {
  return (
    <header className="p-6 flex justify-between items-center bg-slate-800/50 backdrop-blur-md border-b border-white/10">
      <div className="flex items-center gap-2">
        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20">
          <span className="font-black text-xl italic">L</span>
        </div>
        <h1 className="text-2xl font-black tracking-tighter uppercase italic">
          Levis <span className="text-blue-500">Casino</span>
        </h1>
      </div>

      <div className="flex items-center gap-4">
        <div className="bg-slate-900 px-4 py-2 rounded-full flex items-center gap-2 border border-white/5">
          <Coins className="w-5 h-5 text-yellow-500" />
          <span className="font-mono font-bold text-lg">KES {balance.toLocaleString()}</span>
        </div>
        <button 
          onClick={onDeposit}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 transition-colors px-4 py-2 rounded-full font-bold shadow-lg shadow-blue-600/20"
        >
          <PlusCircle className="w-5 h-5" />
          Deposit
        </button>
      </div>
    </header>
  );
};

export default Header;