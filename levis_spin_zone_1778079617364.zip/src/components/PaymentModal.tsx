import React from 'react';
import { motion } from 'framer-motion';
import { X, Smartphone, Landmark, Wallet } from 'lucide-react';

export type PaymentMethod = {
  id: string;
  name: string;
  color: string;
  bgColor: string;
  icon: React.ReactNode;
};

const PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'mpesa',
    name: 'M-Pesa',
    color: 'text-green-500',
    bgColor: 'bg-green-500/10',
    icon: <Smartphone className="w-6 h-6" />,
  },
  {
    id: 'airtel',
    name: 'Airtel Money',
    color: 'text-red-500',
    bgColor: 'bg-red-500/10',
    icon: <Smartphone className="w-6 h-6" />,
  },
  {
    id: 'equity',
    name: 'Equity EazzyPay',
    color: 'text-orange-800',
    bgColor: 'bg-orange-800/10',
    icon: <Landmark className="w-6 h-6" />,
  },
  {
    id: 'tkash',
    name: 'T-Kash',
    color: 'text-orange-500',
    bgColor: 'bg-orange-500/10',
    icon: <Wallet className="w-6 h-6" />,
  },
];

interface PaymentModalProps {
  onClose: () => void;
  onSelect: (method: PaymentMethod) => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ onClose, onSelect }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-slate-900 border border-white/10 rounded-3xl p-6 w-full max-w-md shadow-2xl relative"
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 hover:bg-white/10 rounded-full transition-colors"
        >
          <X className="w-6 h-6 text-slate-400" />
        </button>

        <h2 className="text-2xl font-black mb-1 uppercase italic tracking-tighter">
          Select <span className="text-blue-500">Payment Method</span>
        </h2>
        <p className="text-slate-400 text-sm mb-6">Choose your preferred Kenyan payment service to deposit funds.</p>

        <div className="grid gap-3">
          {PAYMENT_METHODS.map((method) => (
            <button
              key={method.id}
              onClick={() => onSelect(method)}
              className={`flex items-center gap-4 p-4 rounded-2xl border border-white/5 bg-slate-800/50 hover:bg-slate-800 transition-all group active:scale-95`}
            >
              <div className={`w-12 h-12 ${method.bgColor} ${method.color} rounded-xl flex items-center justify-center shadow-inner`}>
                {method.icon}
              </div>
              <div className="text-left flex-1">
                <div className="font-bold text-lg">{method.name}</div>
                <div className="text-xs text-slate-500">Instant deposit • KES</div>
              </div>
              <div className="w-8 h-8 rounded-full bg-blue-600/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
              </div>
            </button>
          ))}
        </div>

        <div className="mt-6 pt-6 border-t border-white/5 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            Secure Encrypted Transaction
          </div>
          <div>Powered by Daraja & PesaPal</div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default PaymentModal;