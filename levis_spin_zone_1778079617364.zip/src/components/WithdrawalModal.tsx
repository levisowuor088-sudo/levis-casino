import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Smartphone, Landmark, Wallet, ArrowUpCircle } from 'lucide-react';
import { PaymentMethod } from './PaymentModal';

const WITHDRAW_METHODS: PaymentMethod[] = [
  {
    id: 'mpesa',
    name: 'M-Pesa',
    color: 'text-green-500',
    bgColor: 'bg-green-500/10',
    icon: <Smartphone className="w-6 h-6" />,
  },
  {
    id: 'airtel',
    name: 'Airtel Money',
    color: 'text-red-500',
    bgColor: 'bg-red-500/10',
    icon: <Smartphone className="w-6 h-6" />,
  },
  {
    id: 'equity',
    name: 'Equity EazzyPay',
    color: 'text-orange-800',
    bgColor: 'bg-orange-800/10',
    icon: <Landmark className="w-6 h-6" />,
  },
  {
    id: 'tkash',
    name: 'T-Kash',
    color: 'text-orange-500',
    bgColor: 'bg-orange-500/10',
    icon: <Wallet className="w-6 h-6" />,
  },
];

interface WithdrawalModalProps {
  balance: number;
  onClose: () => void;
  onWithdraw: (amount: number, methodId: string) => void;
}

const WithdrawalModal: React.FC<WithdrawalModalProps> = ({ balance, onClose, onWithdraw }) => {
  const [amount, setAmount] = useState<string>('20');
  const [selectedMethod, setSelectedMethod] = useState<string>('mpesa');
  const [error, setError] = useState<string | null>(null);

  const MIN_WITHDRAWAL = 20;

  const handleWithdraw = () => {
    const numAmount = parseFloat(amount);
    
    if (isNaN(numAmount) || numAmount < MIN_WITHDRAWAL) {
      setError(`Minimum withdrawal is KES ${MIN_WITHDRAWAL}`);
      return;
    }
    
    if (numAmount > balance) {
      setError('Insufficient balance');
      return;
    }

    setError(null);
    onWithdraw(numAmount, selectedMethod);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-slate-900 border border-white/10 rounded-3xl p-6 w-full max-w-md shadow-2xl relative"
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 hover:bg-white/10 rounded-full transition-colors"
        >
          <X className="w-6 h-6 text-slate-400" />
        </button>

        <h2 className="text-2xl font-black mb-1 uppercase italic tracking-tighter">
          Withdraw <span className="text-blue-500">Funds</span>
        </h2>
        <p className="text-slate-400 text-sm mb-6">Enter the amount and select your withdrawal method.</p>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase text-slate-500 mb-2 ml-1">Amount (KES)</label>
            <div className="relative">
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={`Min ${MIN_WITHDRAWAL}`}
                className="w-full bg-slate-800 border border-white/10 rounded-2xl px-4 py-4 text-xl font-bold focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold">
                KES
              </div>
            </div>
            {error && (
              <p className="text-red-500 text-xs mt-2 font-bold ml-1">{error}</p>
            )}
            <p className="text-slate-500 text-xs mt-2 ml-1">Available: <span className="text-white font-bold">KES {balance.toLocaleString()}</span></p>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-slate-500 mb-2 ml-1">Withdraw to</label>
            <div className="grid grid-cols-2 gap-2">
              {WITHDRAW_METHODS.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setSelectedMethod(method.id)}
                  className={`flex flex-col items-center gap-2 p-3 rounded-2xl border transition-all ${
                    selectedMethod === method.id
                      ? 'bg-blue-600/20 border-blue-500 ring-1 ring-blue-500'
                      : 'bg-slate-800/50 border-white/5 hover:bg-slate-800'
                  }`}
                >
                  <div className={`w-10 h-10 ${method.bgColor} ${method.color} rounded-xl flex items-center justify-center`}>
                    {method.icon}
                  </div>
                  <span className="text-xs font-bold">{method.name}</span>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleWithdraw}
            className="w-full py-4 rounded-2xl font-black text-xl uppercase tracking-widest flex items-center justify-center gap-3 transition-all transform active:scale-95 shadow-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-blue-500/20 mt-4"
          >
            <ArrowUpCircle className="w-6 h-6" />
            Confirm Withdrawal
          </button>
        </div>

        <div className="mt-6 pt-6 border-t border-white/5 flex items-center justify-between text-xs text-slate-500 text-center w-full">
          <div className="mx-auto">Processing takes 1-5 minutes</div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default WithdrawalModal;