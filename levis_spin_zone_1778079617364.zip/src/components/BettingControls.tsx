import React from 'react';
import { Play, PlusCircle, ArrowUpCircle } from 'lucide-react';

interface BettingControlsProps {
  bet: number;
  setBet: (val: number) => void;
  onSpin: () => void;
  onDeposit: () => void;
  onWithdraw: () => void;
  disabled: boolean;
  balance: number;
}

const BettingControls: React.FC<BettingControlsProps> = ({ 
  bet, 
  setBet, 
  onSpin, 
  onDeposit, 
  onWithdraw,
  disabled, 
  balance 
}) => {
  const betOptions = [10, 50, 100, 500];

  return (
    <div className="space-y-6">
      <div className="flex gap-2 justify-center">
        {betOptions.map((opt) => (
          <button
            key={opt}
            disabled={disabled}
            onClick={() => setBet(opt)}
            className={`px-4 py-2 rounded-lg font-bold transition-all ${
              bet === opt 
                ? 'bg-blue-600 ring-2 ring-blue-400' 
                : 'bg-slate-800 hover:bg-slate-700'
            } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            KES {opt}
          </button>
        ))}
      </div>

      <div className="relative group space-y-3">
        {balance < bet ? (
          <button
            onClick={onDeposit}
            className="w-full py-4 rounded-2xl font-black text-2xl uppercase tracking-widest flex items-center justify-center gap-3 transition-all transform active:scale-95 shadow-xl bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white shadow-green-500/20"
          >
            <PlusCircle className="w-8 h-8" fill="currentColor" />
            Deposit to Play
          </button>
        ) : (
          <button
            onClick={onSpin}
            disabled={disabled}
            className={`w-full py-4 rounded-2xl font-black text-2xl uppercase tracking-widest flex items-center justify-center gap-3 transition-all transform active:scale-95 shadow-xl ${
              disabled
                ? 'bg-slate-700 cursor-not-allowed text-slate-500'
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-blue-500/20'
            }`}
          >
            <Play className={`w-8 h-8 ${disabled ? '' : 'animate-pulse'}`} fill="currentColor" />
            Spin Now
          </button>
        )}
        
        <div className="grid grid-cols-2 gap-3 mt-4">
          <button
            onClick={onDeposit}
            className="py-3 rounded-xl font-bold flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 border border-white/5 transition-all active:scale-95"
          >
            <PlusCircle className="w-5 h-5 text-green-500" />
            Deposit
          </button>
          <button
            onClick={onWithdraw}
            className="py-3 rounded-xl font-bold flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 border border-white/5 transition-all active:scale-95"
          >
            <ArrowUpCircle className="w-5 h-5 text-blue-500" />
            Withdraw
          </button>
        </div>

        {balance < bet && (
          <p className="text-center text-red-500 text-sm font-bold animate-bounce">
            Insufficient funds! Please deposit to continue.
          </p>
        )}
      </div>
    </div>
  );
};

export default BettingControls;