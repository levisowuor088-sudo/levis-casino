import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, X } from 'lucide-react';

interface WinModalProps {
  amount: number;
  onClose: () => void;
}

const WinModal: React.FC<WinModalProps> = ({ amount, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <motion.div 
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.5, opacity: 0 }}
        className="bg-slate-800 border-2 border-yellow-500 rounded-3xl p-8 max-w-sm w-full relative text-center shadow-2xl shadow-yellow-500/20"
      >
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="w-20 h-20 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
          <Trophy className="w-10 h-10 text-slate-900" />
        </div>

        <h2 className="text-3xl font-black mb-2 uppercase italic italic">BIG WIN!</h2>
        <p className="text-slate-400 mb-6 font-medium">You just scored a massive multiplier!</p>
        
        <div className="bg-slate-900 rounded-xl py-4 mb-8">
          <span className="text-5xl font-black text-yellow-500 font-mono">
            +KES {amount.toLocaleString()}
          </span>
        </div>

        <button
          onClick={onClose}
          className="w-full py-4 bg-yellow-500 hover:bg-yellow-400 text-slate-900 font-black rounded-xl transition-colors uppercase tracking-widest"
        >
          Collect Winnings
        </button>
      </motion.div>
    </div>
  );
};

export default WinModal;