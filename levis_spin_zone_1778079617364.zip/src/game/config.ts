import Phaser from 'phaser';

const SECTORS = [
  { label: '0x', color: 0x334155, multiplier: 0 },
  { label: '2x', color: 0x3b82f6, multiplier: 2 },
  { label: '0x', color: 0x334155, multiplier: 0 },
  { label: '5x', color: 0x8b5cf6, multiplier: 5 },
  { label: '0x', color: 0x334155, multiplier: 0 },
  { label: '10x', color: 0xec4899, multiplier: 10 },
  { label: '0x', color: 0x334155, multiplier: 0 },
  { label: '2x', color: 0x3b82f6, multiplier: 2 },
  { label: '0x', color: 0x334155, multiplier: 0 },
  { label: '50x', color: 0xeab308, multiplier: 50 },
  { label: '0x', color: 0x334155, multiplier: 0 },
  { label: '5x', color: 0x8b5cf6, multiplier: 5 },
];

class MainScene extends Phaser.Scene {
  private wheel!: Phaser.GameObjects.Container;
  private isSpinning: boolean = false;
  private onCompleteCallback: (multiplier: number) => void;

  constructor(onComplete: (multiplier: number) => void) {
    super('MainScene');
    this.onCompleteCallback = onComplete;
  }

  create() {
    const { width, height } = this.scale;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) * 0.45;

    this.wheel = this.add.container(centerX, centerY);

    const angleStep = (Math.PI * 2) / SECTORS.length;

    SECTORS.forEach((sector, i) => {
      const startAngle = i * angleStep - Math.PI / 2;
      const endAngle = (i + 1) * angleStep - Math.PI / 2;

      const graphics = this.add.graphics();
      graphics.fillStyle(sector.color, 1);
      graphics.lineStyle(4, 0x1e293b, 1);
      
      graphics.beginPath();
      graphics.moveTo(0, 0);
      graphics.arc(0, 0, radius, startAngle, endAngle);
      graphics.closePath();
      graphics.fillPath();
      graphics.strokePath();

      this.wheel.add(graphics);

      const textAngle = startAngle + angleStep / 2;
      const tx = Math.cos(textAngle) * (radius * 0.7);
      const ty = Math.sin(textAngle) * (radius * 0.7);

      const text = this.add.text(tx, ty, sector.label, {
        fontSize: '24px',
        color: '#ffffff',
        fontStyle: 'bold',
        stroke: '#000000',
        strokeThickness: 4
      });
      text.setOrigin(0.5);
      text.setRotation(textAngle + Math.PI / 2);
      this.wheel.add(text);
    });

    const pointer = this.add.graphics();
    pointer.fillStyle(0xffffff, 1);
    pointer.fillTriangle(
      centerX - 20, centerY - radius - 10,
      centerX + 20, centerY - radius - 10,
      centerX, centerY - radius + 30
    );
    pointer.lineStyle(2, 0x000000, 1);
    pointer.strokeTriangle(
      centerX - 20, centerY - radius - 10,
      centerX + 20, centerY - radius - 10,
      centerX, centerY - radius + 30
    );

    this.game.events.on('spin-request', this.spin, this);
  }

  spin() {
    if (this.isSpinning) return;
    this.isSpinning = true;

    const rounds = Phaser.Math.Between(5, 10);
    const degrees = Phaser.Math.Between(0, 360);
    const totalRotation = rounds * 360 + degrees;

    this.tweens.add({
      targets: this.wheel,
      angle: totalRotation,
      duration: 4000,
      ease: 'Cubic.easeOut',
      onComplete: () => {
        this.isSpinning = false;
        // Normalize angle: 0 is top.
        // Rotation is clockwise. If container angle is 90, sector at -90 moved to 0.
        // index = floor( (360 - (angle % 360)) / (360/count) )
        const currentAngle = (this.wheel.angle % 360 + 360) % 360;
        const sectorAngle = 360 / SECTORS.length;
        const index = Math.floor(((360 - currentAngle) % 360) / sectorAngle);
        const result = SECTORS[index % SECTORS.length];
        this.onCompleteCallback(result.multiplier);
      }
    });
  }
}

export const createGameConfig = (onComplete: (multiplier: number) => void): Phaser.Types.Core.GameConfig => ({
  type: Phaser.AUTO,
  parent: 'game-container',
  width: 600,
  height: 600,
  backgroundColor: 'rgba(0,0,0,0)',
  transparent: true,
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH
  },
  scene: new MainScene(onComplete)
});