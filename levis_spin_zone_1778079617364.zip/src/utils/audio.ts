import { Howl } from 'howler';

const sounds: Record<string, Howl> = {
  bgm: new Howl({
    src: ['https://assets.mixkit.co/music/preview/mixkit-casino-night-31.mp3'],
    loop: true,
    volume: 0.2,
    autoplay: false,
  }),
  spin: new Howl({
    src: ['https://assets.mixkit.co/sfx/preview/mixkit-mechanical-spin-timer-1534.mp3'],
    volume: 0.5,
  }),
  win: new Howl({
    src: ['https://assets.mixkit.co/sfx/preview/mixkit-winning-chimes-2015.mp3'],
    volume: 0.6,
  }),
  lose: new Howl({
    src: ['https://assets.mixkit.co/sfx/preview/mixkit-funny-fail-low-tone-2856.mp3'],
    volume: 0.4,
  }),
  click: new Howl({
    src: ['https://assets.mixkit.co/sfx/preview/mixkit-light-button-click-1182.mp3'],
    volume: 0.3,
  }),
};

let muted = localStorage.getItem('muted') === 'true';

// Initial state sync
Object.values(sounds).forEach(s => s.mute(muted));

// Start BGM on first interaction
const startBgm = () => {
  if (!sounds.bgm.playing()) {
    sounds.bgm.play();
  }
  document.removeEventListener('click', startBgm);
};
document.addEventListener('click', startBgm);

export const playSound = (key: keyof typeof sounds) => {
  sounds[key].play();
};

export const toggleMute = () => {
  muted = !muted;
  localStorage.setItem('muted', String(muted));
  Object.values(sounds).forEach(s => s.mute(muted));
  return muted;
};

export const isMuted = () => muted;