import React, { useState, useEffect, useRef } from 'react';
import { Game as PhaserGame } from 'phaser';
import { createGameConfig } from './game/config';
import Header from './components/Header';
import BettingControls from './components/BettingControls';
import WinModal from './components/WinModal';
import SoundControls from './components/SoundControls';
import PaymentModal, { PaymentMethod } from './components/PaymentModal';
import WithdrawalModal from './components/WithdrawalModal';
import { playSound } from './utils/audio';
import ReactConfetti from 'react-confetti';
import { motion, AnimatePresence } from 'framer-motion';

const App: React.FC = () => {
  const [balance, setBalance] = useState<number>(1000);
  const [bet, setBet] = useState<number>(10);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [showWinModal, setShowWinModal] = useState<boolean>(false);
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false);
  const [showWithdrawalModal, setShowWithdrawalModal] = useState<boolean>(false);
  const [lastWin, setLastWin] = useState<number>(0);
  const [windowSize, setWindowSize] = useState({ width: window.innerWidth, height: window.innerHeight });

  const gameRef = useRef<PhaserGame | null>(null);

  useEffect(() => {
    const handleResize = () => setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    window.addEventListener('resize', handleResize);
    
    // Initialize Phaser
    const config = createGameConfig((result: number) => {
      handleSpinComplete(result);
    });
    gameRef.current = new PhaserGame(config);

    return () => {
      window.removeEventListener('resize', handleResize);
      gameRef.current?.destroy(true);
    };
  }, []);

  const handleSpinComplete = (multiplier: number) => {
    const winAmount = bet * multiplier;
    setIsSpinning(false);
    
    if (multiplier > 0) {
      setBalance(prev => prev + winAmount);
      setLastWin(winAmount);
      setShowWinModal(true);
      playSound('win');
    } else {
      playSound('lose');
    }
  };

  const handleSpin = () => {
    if (isSpinning || balance < bet) return;
    
    setBalance(prev => prev - bet);
    setIsSpinning(true);
    playSound('spin');

    // Trigger Phaser spin event
    gameRef.current?.events.emit('spin-request');
  };

  /**
   * Opens the Payment Selection Modal
   */
  const openDepositOptions = () => {
    playSound('click');
    setShowPaymentModal(true);
  };

  const openWithdrawalOptions = () => {
    playSound('click');
    setShowWithdrawalModal(true);
  };

  /**
   * Handles the actual deposit redirection based on selected method
   */
  const handleProcessDeposit = (method: PaymentMethod) => {
    setShowPaymentModal(false);
    playSound('click');
    
    const amount = 500; 
    
    let checkoutUrl = '';
    
    switch (method.id) {
      case 'mpesa':
        checkoutUrl = `https://mpesa.example.com/checkout?amount=${amount}&ref=Levis_${Date.now()}`;
        break;
      case 'airtel':
        checkoutUrl = `https://airtel-money.example.com/pay?amount=${amount}&ref=Levis_${Date.now()}`;
        break;
      case 'equity':
        checkoutUrl = `https://eazzypay.example.com/pay?amount=${amount}&ref=Levis_${Date.now()}`;
        break;
      case 'tkash':
        checkoutUrl = `https://tkash.example.com/checkout?amount=${amount}&ref=Levis_${Date.now()}`;
        break;
      default:
        checkoutUrl = `https://payments.example.com/general?method=${method.id}&amount=${amount}`;
    }
    
    alert(`Redirecting to ${method.name} payment gateway for KES ${amount}...`);
    window.location.href = checkoutUrl;
  };

  const handleProcessWithdrawal = (amount: number, methodId: string) => {
    setShowWithdrawalModal(false);
    playSound('click');

    // Validate again just in case (though modal handles it)
    if (amount < 20) {
      alert("Minimum withdrawal is KES 20");
      return;
    }

    if (amount > balance) {
      alert("Insufficient balance");
      return;
    }

    // Process withdrawal logic (simulate)
    setBalance(prev => prev - amount);
    alert(`Withdrawal of KES ${amount.toLocaleString()} to ${methodId.toUpperCase()} has been initiated. Funds will reflect in 1-5 minutes.`);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans overflow-hidden flex flex-col">
      {showWinModal && <ReactConfetti width={windowSize.width} height={windowSize.height} recycle={false} />}
      
      <Header balance={balance} onDeposit={openDepositOptions} />

      <main className="flex-1 flex flex-col items-center justify-center p-4 relative">
        <div id="game-container" className="rounded-full overflow-hidden shadow-2xl shadow-blue-500/20 border-8 border-slate-800 aspect-square max-w-[90vw] max-h-[60vh]" />
        
        <div className="mt-8 w-full max-w-md">
          <BettingControls 
            bet={bet} 
            setBet={setBet} 
            onSpin={handleSpin} 
            onDeposit={openDepositOptions}
            onWithdraw={openWithdrawalOptions}
            disabled={isSpinning} 
            balance={balance}
          />
        </div>
      </main>

      <SoundControls />

      <AnimatePresence>
        {showWinModal && (
          <WinModal 
            amount={lastWin} 
            onClose={() => setShowWinModal(false)} 
          />
        )}
        
        {showPaymentModal && (
          <PaymentModal 
            onClose={() => setShowPaymentModal(false)} 
            onSelect={handleProcessDeposit}
          />
        )}

        {showWithdrawalModal && (
          <WithdrawalModal
            balance={balance}
            onClose={() => setShowWithdrawalModal(false)}
            onWithdraw={handleProcessWithdrawal}
          />
        )}
      </AnimatePresence>

      <footer className="p-4 text-center text-slate-500 text-sm">
        &copy; 2024 Levis Casino - Play Responsibly
      </footer>
    </div>
  );
};

export default App;